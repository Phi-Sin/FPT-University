<%-- 
    Document   : admin
    Created on : Sep 29, 2022, 7:51:46 AM
    Author     : Acer
--%>

<%@page import="java.util.List"%>
<%@page import="sample.user.UserDTO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Admin Page</title>
        <link href="CSS/AdminStyle.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <%
            UserDTO loginUser = (UserDTO) session.getAttribute("LOGIN_USER");
            if (loginUser == null || !"AD".equals(loginUser.getRoleID())) {
                response.sendRedirect("login.html");
                return;
            }
            String search = request.getParameter("search");
            if (search != null) {
                search = "";
            }
//            if(user==null){
//                user=new UserDTO();
//            }
        %>
        <div class="admin-wrapper">
            <div class="form">
                <img src="img/loginIcon.png" alt="">
                <div class="welcome"> Welcome Back: <h1><%= loginUser.getFullName()%></h1> </div>
                <a href="MainController?action=Logout"></a> 
                <form action="MainController">
                    <input type="submit" name="action" value="Logout" class="Logout-btn"/>
                </form>
                <form action="MainController" class="search-input">
                    Search   <input type="text" name="search" value=""<%= request.getParameter("search")%>/>
                    <input type="submit" name="action" value="Search"/>
                </form>
                    <br>
                <%
                    List<UserDTO> listUser = (List<UserDTO>) request.getAttribute("LIST_USER");
                    if (listUser != null) {
                        if (listUser.size() > 0) {
                %>
                <table border="1">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>User ID</th>
                            <th>Full Name</th>
                            <th>Role ID</th>
                            <th>Password</th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            int count = 0;
                            for (UserDTO user : listUser) {
                        %>
                    <form action="MainController" method="POST">               
                        <tr>
                            <td><%= ++count%></td>
                            <td>
                                <input type="text" name="userID" value="<%= user.getUserID()%>" readonly=""/>
                            </td>
                            <td>
                                <input type="text" name="fullName" value="<%= user.getFullName()%>" required=""/>
                            </td>
                            <td>
                                <input type="text" name="roleID" value="<%= user.getRoleID()%>" required=""/>
                            </td>
                            <td><%= user.getPassword()%></td>
                            <!--Delete o day ne-->
                            <td>
                                <a href="MainController?userID=<%= user.getUserID()%>&action=Delete&search=<%= search%>">Delete</a>
                            </td>
                            <!--Update o day ne-->
                            <td>
                                <input type="submit" name="action" value="Update"/>
                                <input type="hidden" name="search" value="<%= search%>"/>
                            </td>
                        </tr>
                    </form>
            </div>

        </div>


        <%
            }
        %>
    </tbody>
</table>
<%
    String error = (String) request.getAttribute("ERROR");
    if (error == null) {
        error = "";
    }
%>
<%= error%>
<%
        }
    }
%>
</body>
</html>
